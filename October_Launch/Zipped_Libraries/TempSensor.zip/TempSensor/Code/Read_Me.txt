The code is provided under the MIT license please use, edit, change, and share. 

Before loading the DS18S20 code, or even opening the arduino software, place the OneWire folder in your arduino library.

////ARDUINO LIBRARY LOCATION////
On your Mac:: In (home directory)/Documents/Arduino/libraries
On your PC:: My Documents -> Arduino -> libraries
On your Linux box: (home directory)/sketchbook/libraries